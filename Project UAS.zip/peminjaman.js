function redirectToPeminjaman(){
    window.location.href = "pages/peminjaman.html";
}

function validateForm() {
    const NoTransaksi = document.getElementById("NoTransaksi").value.trim();
    const NoIdentitas = document.getElementById("NoIdentitas").value.trim();
    const TanggalPinjam = document.getElementById("TanggalPinjam").value.trim();
    const NamaPeminjam = document.getElementById("NamaPeminjam").value.trim();
    const TanggalKembali = document.getElementById("TanggalKembali").value.trim();
    const KodeBuku = document.getElementById("KodeBuku").value.trim();
    const JudulBuku = document.getElementById("JudulBuku").value.trim();
    const Pengarang = document.getElementById("Pengarang").value.trim();

    if(!NoTransaksi || !NoIdentitas || !TanggalPinjam || !NamaPeminjam || !TanggalKembali || !KodeBuku || !JudulBuku || !Pengarang) {
        alert("Harap isi semua data dengan lengkap sebelum menyimpan!");
        return false;
    }

    alert("Data berhasil disimpan!");
    return true;
}

document.getElementById("TambahBuku").addEventListener("click", function () {
    const KodeBuku = document.getElementById("KodeBuku").value.trim();
    const JudulBuku = document.getElementById("JudulBuku").value.trim();
    const Pengarang = document.getElementById("Pengarang").value.trim();
    const TotalBuku = document.getElementById("TotalBuku").value.trim();

    if (!KodeBuku || !JudulBuku || !Pengarang || !TotalBuku) {
        alert("Harap isi semua data buku!");
        return;
    }

    if (isNaN(TotalBuku) || Number(TotalBuku) <= 0) {
        alert("Total Buku harus berupa angka positif!");
        return;
    }

    const TabelDataBuku = document.getElementById("TabelDataBuku");

    const BarisBaru = document.createElement("tr");

    BarisBaru.innerHTML = `
        <td>${KodeBuku}</td>
        <td>${JudulBuku}</td>
        <td>${Pengarang}</td>
        <td>${TotalBuku}</td>
        <td><button class="hapus">Hapus</button></td>
    `;

    TabelDataBuku.appendChild(BarisBaru);

    document.getElementById("KodeBuku").value = "";
    document.getElementById("JudulBuku").value = "";
    document.getElementById("Pengarang").value = "";
    document.getElementById("TotalBuku").value = "";

    const TombolHapus = BarisBaru.querySelector(".hapus");
    TombolHapus.addEventListener("click", function () {
        TabelDataBuku.removeChild(BarisBaru);
    });
});